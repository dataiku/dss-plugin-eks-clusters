# DSS plugin to manage EKS clusters

This plugin allows you to dynamically create, manage and scale EKS clusters in DSS

Requires DSS 6.0 or above.

For more details, please see https://doc.dataiku.com/dss/latest/containers/eks

## License
Copyright (C) 2019-2022 Dataiku

Licensed under the Apache License, version 2.0
